document.writeln('<script src="http://s4.cnzz.com/stat.php?id=5422368&web_id=5422368" language="JavaScript"></script>');
